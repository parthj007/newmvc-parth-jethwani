<?php

class Model_Customer_Collection extends Model_Core_Table_Collection
{
    public function __construct()
    {
    }
}

?>