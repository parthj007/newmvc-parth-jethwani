<?php
require_once("Model/Core/Table/Row.php");

class Model_Salesman_Address_Row extends Model_Core_Table_Row
{

    protected $tableClass = 'Model_Salesman_Address';

}

?>