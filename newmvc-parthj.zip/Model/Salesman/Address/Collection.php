<?php

class Model_Salesman_Address_Collection extends Model_Core_Table_Collection
{
    public function __construct()
    {
    }
}

?>