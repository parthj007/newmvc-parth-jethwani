<?php
/**
 * 
 */
class Model_Eav_Attribute_InputType extends Model_Core_Table
{	
	protected $resourceClass = "Eav_Attribute_InputType_Resource";
	protected $collectionClass = "Eav_Attribute_InputType_Collection";
}