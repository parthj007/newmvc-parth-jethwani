 

<?php

class Model_Eav_Attribute_Option extends Model_Core_Table
{
    protected $resourceClass = 'Eav_Attribute_Option_Resource';
    protected $collectionClass = 'Eav_Attribute_Option_Collection';
    public function __construct()
    {
        parent::__construct();
    }
}
