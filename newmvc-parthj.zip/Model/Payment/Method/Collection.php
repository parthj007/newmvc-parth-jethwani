<?php

class Model_Payment_Method_Collection extends Model_Core_Table_Collection
{
    public function __construct()
    {
    }
}