<?php
class Model_Brand_Collection extends Model_Core_Table_Collection
{
    function __construct()
    {
    }


}

?>