<?php 
class Model_Vendor_Address extends Model_Core_Table
{
	protected $resourceClass = "Vendor_Address_Resource";
    protected $collectionClass = "Vendor_Address_Collection";
}
?>