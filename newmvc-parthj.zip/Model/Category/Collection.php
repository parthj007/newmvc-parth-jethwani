<?php

class Model_Category_Collection extends Model_Core_Table_Collection
{
    function __construct()
    {
    }
}

?>