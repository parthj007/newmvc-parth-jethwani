<?php

class Model_Quote_Collection extends Model_Core_Table_Collection
{
    public function __construct()
    {
    }
}

?>